declare class SolarWeek {
    private readonly _year;
    private readonly _month;
    private readonly _day;
    private readonly _start;
    static fromYmd(year: number, month: number, day: number, start: number): SolarWeek;
    static fromDate(date: Date, start: number): SolarWeek;
    constructor(year: number, month: number, day: number, start: number);
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getStart(): number;
    getIndex(): number;
    getIndexInYear(): number;
    next(weeks: number, separateMonth: boolean): SolarWeek;
    getFirstDay(): Solar;
    getFirstDayInMonth(): Solar;
    getDays(): Solar[];
    getDaysInMonth(): Solar[];
    toString(): string;
    toFullString(): string;
}

declare class JieQi {
    private _name;
    private _solar;
    private readonly _jie;
    private readonly _qi;
    constructor(name: string, solar: Solar);
    getName(): string;
    getSolar(): Solar;
    setName(name: string): void;
    setSolar(solar: Solar): void;
    isJie(): boolean;
    isQi(): boolean;
    toString(): string;
}

declare class LiuYue {
    private readonly _index;
    private _liuNian;
    constructor(liuNian: LiuNian, index: number);
    getIndex(): number;
    getMonthInChinese(): string;
    getGanZhi(): string;
    getXun(): string;
    getXunKong(): string;
}

declare class LiuNian {
    private readonly _year;
    private readonly _age;
    private readonly _index;
    private _daYun;
    private readonly _lunar;
    constructor(daYun: DaYun, index: number);
    getYear(): number;
    getAge(): number;
    getIndex(): number;
    getLunar(): Lunar;
    getGanZhi(): string;
    getXun(): string;
    getXunKong(): string;
    getLiuYue(): LiuYue[];
}

declare class XiaoYun {
    private readonly _year;
    private readonly _age;
    private readonly _index;
    private _daYun;
    private _lunar;
    private readonly _forward;
    constructor(daYun: DaYun, index: number, forward: boolean);
    getYear(): number;
    getAge(): number;
    getIndex(): number;
    getGanZhi(): string;
    getXun(): string;
    getXunKong(): string;
}

declare class DaYun {
    private readonly _startYear;
    private readonly _endYear;
    private readonly _startAge;
    private readonly _endAge;
    private readonly _index;
    private _yun;
    private readonly _lunar;
    constructor(yun: Yun, index: number);
    getStartYear(): number;
    getEndYear(): number;
    getStartAge(): number;
    getEndAge(): number;
    getIndex(): number;
    getLunar(): Lunar;
    getGanZhi(): string;
    getXun(): string;
    getXunKong(): string;
    getLiuNian(n?: number): LiuNian[];
    getXiaoYun(n?: number): XiaoYun[];
}

declare class Yun {
    private readonly _gender;
    private readonly _startYear;
    private readonly _startMonth;
    private readonly _startDay;
    private readonly _startHour;
    private readonly _forward;
    private readonly _lunar;
    constructor(lunar: Lunar, gender: number, sect?: number);
    getGender(): number;
    getStartYear(): number;
    getStartMonth(): number;
    getStartDay(): number;
    getStartHour(): number;
    isForward(): boolean;
    getLunar(): Lunar;
    getStartSolar(): Solar;
    getDaYun(n?: number): DaYun[];
}

declare class EightChar {
    private _sect;
    private readonly _lunar;
    static fromLunar(lunar: Lunar): EightChar;
    constructor(lunar: Lunar);
    getSect(): number;
    setSect(sect: number): void;
    getDayGanIndex(): number;
    getDayZhiIndex(): number;
    getYear(): string;
    getYearGan(): string;
    getYearZhi(): string;
    getYearHideGan(): string[];
    getYearWuXing(): string;
    getYearNaYin(): string;
    getYearShiShenGan(): string;
    getYearShiShenZhi(): string[];
    getDiShi(zhiIndex: number): string;
    getYearDiShi(): string;
    getYearXun(): string;
    getYearXunKong(): string;
    getMonth(): string;
    getMonthGan(): string;
    getMonthZhi(): string;
    getMonthHideGan(): string[];
    getMonthWuXing(): string;
    getMonthNaYin(): string;
    getMonthShiShenGan(): string;
    getMonthShiShenZhi(): string[];
    getMonthDiShi(): string;
    getMonthXun(): string;
    getMonthXunKong(): string;
    getDay(): string;
    getDayGan(): string;
    getDayZhi(): string;
    getDayHideGan(): string[];
    getDayWuXing(): string;
    getDayNaYin(): string;
    getDayShiShenGan(): string;
    getDayShiShenZhi(): string[];
    getDayDiShi(): string;
    getDayXun(): string;
    getDayXunKong(): string;
    getTime(): string;
    getTimeGan(): string;
    getTimeZhi(): string;
    getTimeHideGan(): string[];
    getTimeWuXing(): string;
    getTimeNaYin(): string;
    getTimeShiShenGan(): string;
    getTimeShiShenZhi(): string[];
    getTimeDiShi(): string;
    getTimeXun(): string;
    getTimeXunKong(): string;
    getTaiYuan(): string;
    getTaiYuanNaYin(): string;
    getTaiXi(): string;
    getTaiXiNaYin(): string;
    getMingGong(): string;
    getMingGongNaYin(): string;
    getShenGong(): string;
    getShenGongNaYin(): string;
    getLunar(): Lunar;
    getYun(gender: number, sect?: number): Yun;
    toString(): string;
}

declare class NineStar {
    static NAME_BEI_DOU: string[];
    static NAME_XUAN_KONG: string[];
    static NAME_QI_MEN: string[];
    static BA_MEN_QI_MEN: string[];
    static NAME_TAI_YI: string[];
    static TYPE_TAI_YI: string[];
    static SONG_TAI_YI: string[];
    static LUCK_QI_MEN: string[];
    private readonly _index;
    static fromIndex(index: number): NineStar;
    constructor(index: number);
    getNumber(): string;
    getColor(): string;
    getWuXing(): string;
    getPosition(): string;
    getPositionDesc(): string;
    getNameInXuanKong(): string;
    getNameInBeiDou(): string;
    getNameInQiMen(): string;
    getNameInTaiYi(): string;
    getLuckInQiMen(): string;
    getLuckInXuanKong(): string;
    getYinYangInQiMen(): string;
    getTypeInTaiYi(): string;
    getBaMenInQiMen(): string;
    getSongInTaiYi(): string;
    getIndex(): number;
    toString(): string;
    toFullString(): string;
}

declare class Dictionary<V> {
    protected table: {
        [key: string]: V;
    };
    clear(): void;
    get(key: string): V;
    remove(key: string): V;
    set(key: string, value: V): void;
    constructor(entries?: [string, V][]);
    size(): number;
    isEmpty(): boolean;
    forEach(callback: (key: string, value: V) => any): void;
    containsKey(key: string): boolean;
    keys(): string[];
    values(): V[];
}

declare class ShuJiu {
    private _name;
    private _index;
    constructor(name: string, index: number);
    getName(): string;
    setName(name: string): void;
    getIndex(): number;
    setIndex(index: number): void;
    toString(): string;
    toFullString(): string;
}

declare class Fu {
    private _name;
    private _index;
    constructor(name: string, index: number);
    getName(): string;
    setName(name: string): void;
    getIndex(): number;
    setIndex(index: number): void;
    toString(): string;
    toFullString(): string;
}

declare class LunarMonth {
    private readonly _year;
    private readonly _month;
    private readonly _dayCount;
    private readonly _firstJulianDay;
    private readonly _index;
    private readonly _zhiIndex;
    static fromYm(lunarYear: number, lunarMonth: number): LunarMonth | null;
    constructor(lunarYear: number, lunarMonth: number, dayCount: number, firstJulianDay: number, index: number);
    getYear(): number;
    getMonth(): number;
    getIndex(): number;
    getGanIndex(): number;
    getZhiIndex(): number;
    getGan(): string;
    getZhi(): string;
    getGanZhi(): string;
    isLeap(): boolean;
    getDayCount(): number;
    getFirstJulianDay(): number;
    getPositionXi(): string;
    getPositionXiDesc(): string;
    getPositionYangGui(): string;
    getPositionYangGuiDesc(): string;
    getPositionYinGui(): string;
    getPositionYinGuiDesc(): string;
    getPositionFu(sect?: number): string;
    getPositionFuDesc(sect?: number): string;
    getPositionCai(): string;
    getPositionCaiDesc(): string;
    getPositionTaiSui(): string;
    getPositionTaiSuiDesc(): string;
    getNineStar(): NineStar;
    toString(): string;
    next(n: number): LunarMonth | null;
}

declare class LunarYear {
    private readonly _year;
    private readonly _ganIndex;
    private readonly _zhiIndex;
    private readonly _months;
    private readonly _jieQiJulianDays;
    static YUAN: string[];
    static YUN: string[];
    private static _LEAP_11;
    private static _LEAP_12;
    private static _CACHE_YEAR;
    static fromYear(lunarYear: number): LunarYear;
    constructor(lunarYear: number);
    private compute;
    getYear(): number;
    getGanIndex(): number;
    getZhiIndex(): number;
    getGan(): string;
    getZhi(): string;
    getGanZhi(): string;
    getJieQiJulianDays(): number[];
    getDayCount(): number;
    getMonths(): LunarMonth[];
    getMonthsInYear(): LunarMonth[];
    getMonth(lunarMonth: number): LunarMonth | null;
    getLeapMonth(): number;
    toString(): string;
    toFullString(): string;
    private _getZaoByGan;
    private _getZaoByZhi;
    getTouLiang(): string;
    getCaoZi(): string;
    getGengTian(): string;
    getHuaShou(): string;
    getZhiShui(): string;
    getTuoGu(): string;
    getQiangMi(): string;
    getKanCan(): string;
    getGongZhu(): string;
    getJiaTian(): string;
    getFenBing(): string;
    getDeJin(): string;
    getRenBing(): string;
    getRenChu(): string;
    getYuan(): string;
    getYun(): string;
    getNineStar(): NineStar;
    getPositionXi(): string;
    getPositionXiDesc(): string;
    getPositionYangGui(): string;
    getPositionYangGuiDesc(): string;
    getPositionYinGui(): string;
    getPositionYinGuiDesc(): string;
    getPositionFu(sect?: number): string;
    getPositionFuDesc(sect?: number): string;
    getPositionCai(): string;
    getPositionCaiDesc(): string;
    getPositionTaiSui(): string;
    getPositionTaiSuiDesc(): string;
    next(n: number): LunarYear;
}

declare class LunarTime {
    private readonly _ganIndex;
    private readonly _zhiIndex;
    private _lunar;
    static fromYmdHms(lunarYear: number, lunarMonth: number, lunarDay: number, hour: number, minute: number, second: number): LunarTime;
    constructor(lunarYear: number, lunarMonth: number, lunarDay: number, hour: number, minute: number, second: number);
    getGanIndex(): number;
    getZhiIndex(): number;
    getGan(): string;
    getZhi(): string;
    getGanZhi(): string;
    getShengXiao(): string;
    getPositionXi(): string;
    getPositionXiDesc(): string;
    getPositionYangGui(): string;
    getPositionYangGuiDesc(): string;
    getPositionYinGui(): string;
    getPositionYinGuiDesc(): string;
    getPositionFu(sect?: number): string;
    getPositionFuDesc(sect?: number): string;
    getPositionCai(): string;
    getPositionCaiDesc(): string;
    getNaYin(): string;
    getTianShen(): string;
    getTianShenType(): string;
    getTianShenLuck(): string;
    getChong(): string;
    getSha(): string;
    getChongShengXiao(): string;
    getChongDesc(): string;
    getChongGan(): string;
    getChongGanTie(): string;
    getYi(): string[];
    getJi(): string[];
    getNineStar(): NineStar;
    getXun(): string;
    getXunKong(): string;
    getMinHm(): string;
    getMaxHm(): string;
    toString(): string;
}

declare class FotoFestival {
    private readonly _name;
    private readonly _result;
    private readonly _everyMonth;
    private readonly _remark;
    constructor(name: string, result?: string, everyMonth?: boolean, remark?: string);
    getName(): string;
    getResult(): string;
    isEveryMonth(): boolean;
    getRemark(): string;
    toString(): string;
    toFullString(): string;
}

declare class Foto {
    private readonly _lunar;
    static DEAD_YEAR: number;
    constructor(lunar: Lunar);
    static fromLunar(lunar: Lunar): Foto;
    static fromYmdHms(lunarYear: number, lunarMonth: number, lunarDay: number, hour: number, minute: number, second: number): Foto;
    static fromYmd(lunarYear: number, lunarMonth: number, lunarDay: number): Foto;
    getLunar(): Lunar;
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getYearInChinese(): string;
    getMonthInChinese(): string;
    getDayInChinese(): string;
    getFestivals(): FotoFestival[];
    getOtherFestivals(): string[];
    isMonthZhai(): boolean;
    isDayYangGong(): boolean;
    isDayZhaiShuoWang(): boolean;
    isDayZhaiSix(): boolean;
    isDayZhaiTen(): boolean;
    isDayZhaiGuanYin(): boolean;
    getXiu(): string;
    getXiuLuck(): string;
    getXiuSong(): string;
    getZheng(): string;
    getAnimal(): string;
    getGong(): string;
    getShou(): string;
    toString(): string;
    toFullString(): string;
}

declare class TaoFestival {
    private readonly _name;
    private readonly _remark;
    constructor(name: string, remark?: string);
    getName(): string;
    getRemark(): string;
    toString(): string;
    toFullString(): string;
}

declare class Tao {
    private readonly _lunar;
    static BIRTH_YEAR: number;
    constructor(lunar: Lunar);
    static fromLunar(lunar: Lunar): Tao;
    static fromYmdHms(lunarYear: number, lunarMonth: number, lunarDay: number, hour: number, minute: number, second: number): Tao;
    static fromYmd(lunarYear: number, lunarMonth: number, lunarDay: number): Tao;
    getLunar(): Lunar;
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getYearInChinese(): string;
    getMonthInChinese(): string;
    getDayInChinese(): string;
    getFestivals(): TaoFestival[];
    private _isDayIn;
    isDaySanHui(): boolean;
    isDaySanYuan(): boolean;
    isDayBaJie(): boolean;
    isDayWuLa(): boolean;
    isDayBaHui(): boolean;
    isDayMingWu(): boolean;
    isDayAnWu(): boolean;
    isDayWu(): boolean;
    isDayTianShe(): boolean;
    toString(): string;
    toFullString(): string;
}

declare class Lunar {
    private _lang;
    private readonly _year;
    private readonly _month;
    private readonly _day;
    private readonly _hour;
    private readonly _minute;
    private readonly _second;
    private readonly _timeGanIndex;
    private readonly _timeZhiIndex;
    private readonly _dayGanIndex;
    private readonly _dayZhiIndex;
    private readonly _dayGanIndexExact;
    private readonly _dayZhiIndexExact;
    private readonly _dayGanIndexExact2;
    private readonly _dayZhiIndexExact2;
    private readonly _monthGanIndex;
    private readonly _monthZhiIndex;
    private readonly _monthGanIndexExact;
    private readonly _monthZhiIndexExact;
    private readonly _yearGanIndex;
    private readonly _yearZhiIndex;
    private readonly _yearGanIndexByLiChun;
    private readonly _yearZhiIndexByLiChun;
    private readonly _yearGanIndexExact;
    private readonly _yearZhiIndexExact;
    private readonly _weekIndex;
    private _jieQi;
    private _jieQiList;
    private readonly _solar;
    private readonly _eightChar;
    static fromYmd(lunarYear: number, lunarMonth: number, lunarDay: number): Lunar;
    static fromYmdHms(lunarYear: number, lunarMonth: number, lunarDay: number, hour: number, minute: number, second: number): Lunar;
    static fromSolar(solar: Solar): Lunar;
    static fromDate(date: Date): Lunar;
    private static _computeJieQi;
    private static _computeYear;
    private static _computeMonth;
    private static _computeDay;
    private static _computeTime;
    private static _computeWeek;
    private static _compute;
    constructor(year: number, month: number, day: number, hour: number, minute: number, second: number, solar: Solar, ly: LunarYear);
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getHour(): number;
    getMinute(): number;
    getSecond(): number;
    getTimeGanIndex(): number;
    getTimeZhiIndex(): number;
    getDayGanIndex(): number;
    getDayZhiIndex(): number;
    getMonthGanIndex(): number;
    getMonthZhiIndex(): number;
    getYearGanIndex(): number;
    getYearZhiIndex(): number;
    getYearGanIndexByLiChun(): number;
    getYearZhiIndexByLiChun(): number;
    getDayGanIndexExact(): number;
    getDayZhiIndexExact(): number;
    getDayGanIndexExact2(): number;
    getDayZhiIndexExact2(): number;
    getMonthGanIndexExact(): number;
    getMonthZhiIndexExact(): number;
    getYearGanIndexExact(): number;
    getYearZhiIndexExact(): number;
    getGan(): string;
    getZhi(): string;
    getYearGan(): string;
    getYearGanByLiChun(): string;
    getYearGanExact(): string;
    getYearZhi(): string;
    getYearZhiByLiChun(): string;
    getYearZhiExact(): string;
    getYearInGanZhi(): string;
    getYearInGanZhiByLiChun(): string;
    getYearInGanZhiExact(): string;
    getMonthGan(): string;
    getMonthGanExact(): string;
    getMonthZhi(): string;
    getMonthZhiExact(): string;
    getMonthInGanZhi(): string;
    getMonthInGanZhiExact(): string;
    getDayGan(): string;
    getDayGanExact(): string;
    getDayGanExact2(): string;
    getDayZhi(): string;
    getDayZhiExact(): string;
    getDayZhiExact2(): string;
    getDayInGanZhi(): string;
    getDayInGanZhiExact(): string;
    getDayInGanZhiExact2(): string;
    getTimeGan(): string;
    getTimeZhi(): string;
    getTimeInGanZhi(): string;
    getShengxiao(): string;
    getYearShengXiao(): string;
    getYearShengXiaoByLiChun(): string;
    getYearShengXiaoExact(): string;
    getMonthShengXiao(): string;
    getMonthShengXiaoExact(): string;
    getDayShengXiao(): string;
    getTimeShengXiao(): string;
    getYearInChinese(): string;
    getMonthInChinese(): string;
    getDayInChinese(): string;
    getPengZuGan(): string;
    getPengZuZhi(): string;
    getPositionXi(): string;
    getPositionXiDesc(): string;
    getPositionYangGui(): string;
    getPositionYangGuiDesc(): string;
    getPositionYinGui(): string;
    getPositionYinGuiDesc(): string;
    getPositionFu(): string;
    getPositionFuDesc(): string;
    getPositionCai(): string;
    getPositionCaiDesc(): string;
    getDayPositionXi(): string;
    getDayPositionXiDesc(): string;
    getDayPositionYangGui(): string;
    getDayPositionYangGuiDesc(): string;
    getDayPositionYinGui(): string;
    getDayPositionYinGuiDesc(): string;
    getDayPositionFu(sect?: number): string;
    getDayPositionFuDesc(sect?: number): string;
    getDayPositionCai(): string;
    getDayPositionCaiDesc(): string;
    getTimePositionXi(): string;
    getTimePositionXiDesc(): string;
    getTimePositionYangGui(): string;
    getTimePositionYangGuiDesc(): string;
    getTimePositionYinGui(): string;
    getTimePositionYinGuiDesc(): string;
    getTimePositionFu(sect?: number): string;
    getTimePositionFuDesc(sect?: number): string;
    getTimePositionCai(): string;
    getTimePositionCaiDesc(): string;
    getYearPositionTaiSui(sect?: number): string;
    getYearPositionTaiSuiDesc(sect?: number): string;
    getMonthPositionTaiSui(sect?: number): string;
    getMonthPositionTaiSuiDesc(sect?: number): string;
    getDayPositionTaiSui(sect?: number): string;
    getDayPositionTaiSuiDesc(sect?: number): string;
    getChong(): string;
    getChongGan(): string;
    getChongGanTie(): string;
    getChongShengXiao(): string;
    getChongDesc(): string;
    getSha(): string;
    getDayChong(): string;
    getDayChongGan(): string;
    getDayChongGanTie(): string;
    getDayChongShengXiao(): string;
    getDayChongDesc(): string;
    getDaySha(): string;
    getTimeChong(): string;
    getTimeChongGan(): string;
    getTimeChongGanTie(): string;
    getTimeChongShengXiao(): string;
    getTimeChongDesc(): string;
    getTimeSha(): string;
    getYearNaYin(): string;
    getMonthNaYin(): string;
    getDayNaYin(): string;
    getTimeNaYin(): string;
    getSeason(): string;
    private static _convertJieQi;
    private checkLang;
    getJie(): string;
    getQi(): string;
    getJieQi(): string;
    getWeek(): number;
    getWeekInChinese(): string;
    getXiu(): string;
    getXiuLuck(): string;
    getXiuSong(): string;
    getZheng(): string;
    getAnimal(): string;
    getGong(): string;
    getShou(): string;
    getFestivals(): string[];
    getOtherFestivals(): string[];
    getBaZi(): string[];
    getBaZiWuXing(): string[];
    getBaZiNaYin(): string[];
    getBaZiShiShenGan(): string[];
    getBaZiShiShenZhi(): string[];
    getBaZiShiShenYearZhi(): string[];
    getBaZiShiShenMonthZhi(): string[];
    getBaZiShiShenDayZhi(): string[];
    getBaZiShiShenTimeZhi(): string[];
    getZhiXing(): string;
    getDayTianShen(): string;
    getTimeTianShen(): string;
    getDayTianShenType(): string;
    getTimeTianShenType(): string;
    getDayTianShenLuck(): string;
    getTimeTianShenLuck(): string;
    getDayPositionTai(): string;
    getMonthPositionTai(): string;
    getDayYi(sect?: number): string[];
    getDayJi(sect?: number): string[];
    getDayJiShen(): string[];
    getDayXiongSha(): string[];
    getTimeYi(): string[];
    getTimeJi(): string[];
    getYueXiang(): string;
    private _getYearNineStar;
    getYearNineStar(sect?: number): NineStar;
    getMonthNineStar(sect?: number): NineStar;
    private getJieQiSolar;
    getDayNineStar(): NineStar;
    getTimeNineStar(): NineStar;
    getSolar(): Solar;
    getJieQiTable(): Dictionary<Solar>;
    getJieQiList(): string[];
    getNextJie(wholeDay?: boolean): JieQi;
    getPrevJie(wholeDay?: boolean): JieQi;
    getNextQi(wholeDay?: boolean): JieQi;
    getPrevQi(wholeDay?: boolean): JieQi;
    getNextJieQi(wholeDay?: boolean): JieQi;
    getPrevJieQi(wholeDay?: boolean): JieQi;
    private getNearJieQi;
    getCurrentJieQi(): JieQi | null;
    getCurrentJie(): JieQi | null;
    getCurrentQi(): JieQi | null;
    getEightChar(): EightChar;
    next(days: number): Lunar;
    getYearXun(): string;
    getMonthXun(): string;
    getDayXun(): string;
    getTimeXun(): string;
    getYearXunByLiChun(): string;
    getYearXunExact(): string;
    getMonthXunExact(): string;
    getDayXunExact(): string;
    getDayXunExact2(): string;
    getYearXunKong(): string;
    getMonthXunKong(): string;
    getDayXunKong(): string;
    getTimeXunKong(): string;
    getYearXunKongByLiChun(): string;
    getYearXunKongExact(): string;
    getMonthXunKongExact(): string;
    getDayXunKongExact(): string;
    getDayXunKongExact2(): string;
    toString(): string;
    toFullString(): string;
    getShuJiu(): ShuJiu | null;
    getFu(): Fu | null;
    getLiuYao(): string;
    getWuHou(): string;
    getHou(): string;
    getDayLu(): string;
    getTime(): LunarTime;
    getTimes(): LunarTime[];
    getFoto(): Foto;
    getTao(): Tao;
}

declare class Solar {
    static J2000: number;
    private readonly _year;
    private readonly _month;
    private readonly _day;
    private readonly _hour;
    private readonly _minute;
    private readonly _second;
    static fromYmd(year: number, month: number, day: number): Solar;
    static fromYmdHms(year: number, month: number, day: number, hour: number, minute: number, second: number): Solar;
    static fromDate(date: Date): Solar;
    static fromJulianDay(julianDay: number): Solar;
    static fromBaZi(yearGanZhi: string, monthGanZhi: string, dayGanZhi: string, timeGanZhi: string, sect?: number, baseYear?: number): Solar[];
    constructor(year: number, month: number, day: number, hour: number, minute: number, second: number);
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getHour(): number;
    getMinute(): number;
    getSecond(): number;
    getWeek(): number;
    getWeekInChinese(): string;
    getSolarWeek(start: number): SolarWeek;
    isLeapYear(): boolean;
    getFestivals(): string[];
    getOtherFestivals(): string[];
    getXingzuo(): string;
    getXingZuo(): string;
    getSalaryRate(): number;
    toYmd(): string;
    toYmdHms(): string;
    toString(): string;
    toFullString(): string;
    nextYear(years: number): Solar;
    nextMonth(months: number): Solar;
    nextDay(days: number): Solar;
    next(days: number, onlyWorkday?: boolean): Solar;
    nextHour(hours: number): Solar;
    getLunar(): Lunar;
    getJulianDay(): number;
    isBefore(solar: Solar): boolean;
    isAfter(solar: Solar): boolean;
    subtract(solar: Solar): number;
    subtractMinute(solar: Solar): number;
}

declare class SolarUtil {
    static WEEK: string[];
    static DAYS_OF_MONTH: number[];
    static XINGZUO: string[];
    static FESTIVAL: Dictionary<string>;
    static OTHER_FESTIVAL: Dictionary<string[]>;
    static WEEK_FESTIVAL: Dictionary<string>;
    static isLeapYear(year: number): boolean;
    static getDaysOfMonth(year: number, month: number): number;
    static getDaysOfYear(year: number): number;
    static getDaysInYear(year: number, month: number, day: number): number;
    static getWeeksOfMonth(year: number, month: number, start: number): number;
    static getDaysBetween(ay: number, am: number, ad: number, by: number, bm: number, bd: number): number;
}

declare class LunarUtil {
    static BASE_MONTH_ZHI_INDEX: number;
    static XUN: string[];
    static XUN_KONG: string[];
    static CHANG_SHENG: string[];
    static MONTH_ZHI: string[];
    static JIE_QI: string[];
    static JIE_QI_IN_USE: string[];
    static LIU_YAO: string[];
    static HOU: string[];
    static WU_HOU: string[];
    static GAN: string[];
    static POSITION_XI: string[];
    static POSITION_YANG_GUI: string[];
    static POSITION_YIN_GUI: string[];
    static POSITION_FU: string[];
    static POSITION_FU_2: string[];
    static POSITION_CAI: string[];
    static POSITION_TAI_SUI_YEAR: string[];
    static POSITION_GAN: string[];
    static POSITION_ZHI: string[];
    static POSITION_TAI_DAY: string[];
    static POSITION_TAI_MONTH: string[];
    static ZHI: string[];
    static ZHI_XING: string[];
    static JIA_ZI: string[];
    static CHANG_SHENG_OFFSET: Dictionary<number>;
    static TIAN_SHEN: string[];
    static ZHI_TIAN_SHEN_OFFSET: Dictionary<number>;
    static TIAN_SHEN_TYPE: Dictionary<string>;
    static TIAN_SHEN_TYPE_LUCK: Dictionary<string>;
    static LU: Dictionary<string>;
    static PENGZU_GAN: string[];
    static PENGZU_ZHI: string[];
    static NUMBER: string[];
    static MONTH: string[];
    static SEASON: string[];
    static SHENGXIAO: string[];
    static DAY: string[];
    static YUE_XIANG: string[];
    static XIU: Dictionary<string>;
    static XIU_LUCK: Dictionary<string>;
    static XIU_SONG: Dictionary<string>;
    static ZHENG: Dictionary<string>;
    static ANIMAL: Dictionary<string>;
    static GONG: Dictionary<string>;
    static SHOU: Dictionary<string>;
    static FESTIVAL: Dictionary<string>;
    static OTHER_FESTIVAL: Dictionary<string[]>;
    static CHONG: string[];
    static CHONG_GAN: string[];
    static CHONG_GAN_TIE: string[];
    static CHONG_GAN_4: string[];
    static HE_GAN_5: string[];
    static HE_ZHI_6: string[];
    static SHA: Dictionary<string>;
    static POSITION_DESC: Dictionary<string>;
    static NAYIN: Dictionary<string>;
    static WU_XING_GAN: Dictionary<string>;
    static WU_XING_ZHI: Dictionary<string>;
    static SHI_SHEN_GAN: Dictionary<string>;
    static SHI_SHEN_ZHI: Dictionary<string>;
    static ZHI_HIDE_GAN: Dictionary<string[]>;
    private static YI_JI;
    private static DAY_YI_JI;
    private static TIME_YI_JI;
    private static SHEN_SHA;
    private static DAY_SHEN_SHA;
    static getTimeZhiIndex(hm: string): number;
    static convertTime(hm: string): string;
    static getJiaZiIndex(ganZhi: string): number;
    private static hex;
    static getDayYi(monthGanZhi: string, dayGanZhi: string): string[];
    static getDayJi(monthGanZhi: string, dayGanZhi: string): string[];
    static getDayJiShen(lunarMonth: number, dayGanZhi: string): string[];
    static getDayXiongSha(lunarMonth: number, dayGanZhi: string): string[];
    static getTimeYi(dayGanZhi: string, timeGanZhi: string): string[];
    static getTimeJi(dayGanZhi: string, timeGanZhi: string): string[];
    static getXunIndex(ganZhi: string): number;
    static getXun(ganZhi: string): string;
    static getXunKong(ganZhi: string): string;
    static find(
        s: string,
        arr: Array<string>
    ): {
        index: number;
        value: string;
    } | null;
}

declare class FotoUtil {
    static DAY_ZHAI_GUAN_YIN: string[];
    static XIU_27: string[];
    private static XIU_OFFSET;
    static _DJ: string;
    static _JS: string;
    static _SS: string;
    static _XL: string;
    static _JW: string;
    static _Y: FotoFestival;
    static _T: FotoFestival;
    static _D: FotoFestival;
    static _S: FotoFestival;
    static _W: FotoFestival;
    static _H: FotoFestival;
    static _L: FotoFestival;
    static _J: FotoFestival;
    static _R: FotoFestival;
    static _M: FotoFestival;
    static _HH: FotoFestival;
    static FESTIVAL: Dictionary<FotoFestival[]>;
    static OTHER_FESTIVAL: Dictionary<string[]>;
    static getXiu(month: number, day: number): string;
}

declare class TaoUtil {
    static SAN_HUI: string[];
    static SAN_YUAN: string[];
    static WU_LA: string[];
    static AN_WU: string[];
    static BA_HUI: Dictionary<string>;
    static BA_JIE: Dictionary<string>;
    static FESTIVAL: Dictionary<TaoFestival[]>;
}

declare class NineStarUtil {
    static NUMBER: string[];
    static WU_XING: string[];
    static POSITION: string[];
    static LUCK_XUAN_KONG: string[];
    static YIN_YANG_QI_MEN: string[];
    static COLOR: string[];
}

declare class ShouXingUtil {
    static PI_2: number;
    static ONE_THIRD: number;
    static SECOND_PER_DAY: number;
    static SECOND_PER_RAD: number;
    private static NUT_B;
    private static DT_AT;
    private static XL0;
    private static XL1;
    private static QI_KB;
    private static QB;
    private static SHUO_KB;
    private static SB;
    private static decode;
    static nutationLon2(t: number): number;
    static eLon(t: number, n: number): number;
    static mLon(t: number, n: number): number;
    static gxcSunLon(t: number): number;
    static ev(t: number): number;
    static saLon(t: number, n: number): number;
    static dtExt(y: number, jsd: number): number;
    static dtCalc(y: number): number;
    static dtT(t: number): number;
    static mv(t: number): number;
    static saLonT(w: number): number;
    static msaLon(t: number, mn: number, sn: number): number;
    static msaLonT(w: number): number;
    static saLonT2(w: number): number;
    static msaLonT2(w: number): number;
    static qiHigh(w: number): number;
    static shuoHigh(w: number): number;
    static qiLow(w: number): number;
    static shuoLow(w: number): number;
    static calcShuo(jd: number): number;
    static calcQi(jd: number): number;
    static qiAccurate(w: number): number;
    static qiAccurate2(jd: number): number;
}

declare class Holiday {
    private _day;
    private _name;
    private _work;
    private _target;
    constructor(day: string, name: string, work: boolean, target: string);
    private static _ymd;
    getDay(): string;
    setDay(value: string): void;
    getName(): string;
    setName(value: string): void;
    isWork(): boolean;
    setWork(value: boolean): void;
    getTarget(): string;
    setTarget(value: string): void;
    toString(): string;
}

declare class HolidayUtil {
    static NAMES: string[];
    static DATA: string;
    private static _SIZE;
    private static _ZERO;
    private static _TAG_REMOVE;
    private static _NAMES_IN_USE;
    private static _DATA_IN_USE;
    private static _padding;
    private static _findForward;
    private static _findBackward;
    private static _buildHolidayForward;
    private static _buildHolidayBackward;
    private static _findHolidaysForward;
    private static _findHolidaysBackward;
    static getHoliday(yearOrYmd: number | string, month?: number, day?: number): Holiday | null;
    static getHolidays(yearOrYmd: number | string, month?: number): Holiday[];
    static getHolidaysByTarget(yearOrYmd: number | string, month?: number): Holiday[];
    private static _fixNames;
    private static _fixData;
    static fix(a: any, b?: string): void;
}

declare class SolarMonth {
    private readonly _year;
    private readonly _month;
    static fromYm(year: number, month: number): SolarMonth;
    static fromDate(date: Date): SolarMonth;
    constructor(year: number, month: number);
    getYear(): number;
    getMonth(): number;
    next(months: number): SolarMonth;
    getDays(): Solar[];
    getWeeks(start: number): SolarWeek[];
    toString(): string;
    toFullString(): string;
}

declare class SolarSeason {
    private readonly _year;
    private readonly _month;
    static fromYm(year: number, month: number): SolarSeason;
    static fromDate(date: Date): SolarSeason;
    constructor(year: number, month: number);
    getYear(): number;
    getMonth(): number;
    getIndex(): number;
    next(seasons: number): SolarSeason;
    getMonths(): SolarMonth[];
    toString(): string;
    toFullString(): string;
}

declare class SolarHalfYear {
    private readonly _year;
    private readonly _month;
    static fromYm(year: number, month: number): SolarHalfYear;
    static fromDate(date: Date): SolarHalfYear;
    constructor(year: number, month: number);
    getYear(): number;
    getMonth(): number;
    getIndex(): number;
    next(halfYears: number): SolarHalfYear;
    getMonths(): SolarMonth[];
    toString(): string;
    toFullString(): string;
}

declare class SolarYear {
    private readonly _year;
    static fromYear(year: number): SolarYear;
    static fromDate(date: Date): SolarYear;
    constructor(year: number);
    getYear(): number;
    next(years: number): SolarYear;
    getMonths(): SolarMonth[];
    toString(): string;
    toFullString(): string;
}

declare class I18n {
    private static _DEFAULT_LANG;
    private static _LANG;
    private static _INIT;
    private static _MESSAGES;
    private static _OBJS;
    private static _DICT_STRING;
    private static _DICT_NUMBER;
    private static _DICT_ARRAY;
    private static _ARRAYS;
    private static updateArray;
    private static updateStringDictionary;
    private static updateNumberDictionary;
    private static updateArrayDictionary;
    private static update;
    static setMessages(
        lang: string,
        messages: {
            [key: string]: string;
        }
    ): void;
    static getMessage(key: string): string;
    static setLanguage(lang: string): void;
    static getLanguage(): string;
    private static initArray;
    private static initArrayDictionary;
    private static initStringDictionary;
    private static initNumberDictionary;
    static init(): void;
}

export {
    DaYun,
    EightChar,
    Foto,
    FotoUtil,
    Fu,
    Holiday,
    HolidayUtil,
    I18n,
    JieQi,
    LiuNian,
    LiuYue,
    Lunar,
    LunarMonth,
    LunarTime,
    LunarUtil,
    LunarYear,
    NineStar,
    NineStarUtil,
    ShouXingUtil,
    ShuJiu,
    Solar,
    SolarHalfYear,
    SolarMonth,
    SolarSeason,
    SolarUtil,
    SolarWeek,
    SolarYear,
    Tao,
    TaoUtil,
    XiaoYun,
    Yun,
};
