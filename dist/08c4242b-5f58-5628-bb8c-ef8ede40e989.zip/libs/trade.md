const { request } = require('../utils/index.js');

/**
 * 获取股票交易明细
 */
module.exports = async (params = {}) => {
  const url = 'https://push2.eastmoney.com/api/qt/stock/details/get';
  return await request(url, {
    secid: `${params.type}.${params.code}`,
    fields1: 'f1,f2,f3,f4,f5',
    fields2: 'f51,f52,f53,f54,f55',
    pos: '-14',
    iscca: 1,
    invt: 2,
    ...params,
  });
};

参数type 类型（暂定）

其他：0
上证：1
未知: 2
港股：116
美股：105
英股：155code 股票代码

{
  "code": "300750",
  "market": 0,
  "decimal": 2,
  "prePrice": 390.51,
  "details": [{
    "14:56:42,402.08,16,15,2", // 时间,价格,成交量,成交额
  }]
}