const { request } = require('../utils/index.js');

/**
 * 获取股票k线走势图
 */
module.exports = async (params = {}) => {
  const url = 'https://push2his.eastmoney.com/api/qt/stock/kline/get';
  return await request(url, {
    secid: `${params.type}.${params.code}`,
    klt: params.klt,
    lmt: params.lmt,
    fqt: params.fqt,
    end: params.end,
    iscca: 1,
    fields1: 'f1,f2,f3,f4,f5',
    fields2: 'f51,f52,f53,f54,f55,f56,f57',
    ...params,
  });
};

参数type 类型（暂定）

其他：0
上证：1
未知: 2
港股：116
美股：105
英股：155code 股票代码
klt k线类型

日k: 101
周k: 102
月k: 103
1分钟: 1
5分钟: 5
15分钟: 15
30分钟: 30
60分钟: 60
lmt 每页数量

fqt 页数

end 结束时间，例：20230410


{
  "code": "399001",
  "market": 0,
  "name": "深证成指",
  "decimal": 2,
  "dktotal": 7845,
  "klines": [{
    "2023-03-13 10:30,11405.14,11428.89,11511.12,11396.61,166613932,210718299984.00", // 时间,开盘,最高,最低,收盘,成交量,成交额
  }]
}