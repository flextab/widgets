const { request } = require('../utils/index.js');

/**
 * 获取股票走势图
 */
module.exports = async (params = {}) => {
  const url = 'https://push2.eastmoney.com/api/qt/stock/trends2/get';
  return await request(url, {
    secid: `${params.type}.${params.code}`,
    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13',
    fields2: 'f51,f53,f56,f58',
    iscr: 0,
    iscca: 0,
    ndays: params.ndays,
    ...params,
  });
};

```js
var url = `https://push2.eastmoney.com/api/qt/stock/trends2/get?${new URLSearchParams({
    secid: `1.000001`,
    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13',
    fields2: 'f51,f53,f56,f58',
    iscr: 0,
    iscca: 0,
    ndays: [1,5]
}).toString()}`
```

参数type 类型（暂定）

其他：0
上证：1
未知: 2
港股：116
美股：105
英股：155
code 股票代码

ndays 天数 [1,5]

分时: 1
五日: 5

{
    "code": "399001",
    "market": 0,
    "type": 5,
    "status": 0,
    "name": "深证成指",
    "decimal": 2,
    "preSettlement": 0,
    "preClose": 11967.74,
    "beticks": "33300|34200|54000|34200|41400|46800|54000",
    "trendsTotal": 241,
    "time": 1681112058,
    "kind": 2,
    "prePrice": 11967.74,
    "trends": [{
      "2023-04-10 09:30,11987.68,5315278,11974.320", // 时间,价格,成交量,成交额
    }]
  }