<template>
    <div></div>
</template>
<script lang="ts" setup>
import { } from "vue"
</script>
<style lang="scss" scoped></style>